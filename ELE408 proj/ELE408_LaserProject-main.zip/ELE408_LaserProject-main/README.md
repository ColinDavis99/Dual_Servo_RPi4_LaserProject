# ELE408_LaserProject
Dual Servo Laser mount project, use of Rpi4 and rumble 3d joystick controller
